/*
 * phOsal_Freertos.h
 *
 *  Created on: May 12, 2016
 *      Author: nxp69678
 */

#ifndef PHOSAL_NULLOS_H
#define PHOSAL_NULLOS_H

#include <ph_Status.h>

#ifdef NXPBUILD__PH_OSAL_NULLOS

#define PHOSAL_MAX_DELAY      (0xFFFFFFFFU)

#endif /* NXPBUILD__PH_OSAL_NULLOS */

#endif /* PHOSAL_NULLOS_H */
