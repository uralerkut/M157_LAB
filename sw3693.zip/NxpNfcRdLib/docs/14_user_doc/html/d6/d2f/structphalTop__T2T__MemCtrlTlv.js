var structphalTop__T2T__MemCtrlTlv =
[
    [ "wOffset", "d6/d2f/structphalTop__T2T__MemCtrlTlv.html#afff111b8818e43787f689881876c1598", null ],
    [ "wByteAddr", "d6/d2f/structphalTop__T2T__MemCtrlTlv.html#a4506a38273ddc7839cf0a76b9ae39af1", null ],
    [ "bSizeInBytes", "d6/d2f/structphalTop__T2T__MemCtrlTlv.html#a5d1353e6119807fef6c95f9eebd6c3fb", null ],
    [ "bBytesPerPage", "d6/d2f/structphalTop__T2T__MemCtrlTlv.html#a7e81357fad235c8b6742830eec512500", null ]
];