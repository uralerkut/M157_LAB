var structphNfcLib__I18000p3m3 =
[
    [ "bCommand", "d6/d78/structphNfcLib__I18000p3m3.html#a43474ef369d536025ffc30ab46928c58", null ],
    [ "bOption", "d6/d78/structphNfcLib__I18000p3m3.html#a2445099a31a4f3c6cb20e005b57b8460", null ],
    [ "bMemBank", "d6/d78/structphNfcLib__I18000p3m3.html#a64a1bc0d31e6747953e788c9c5d740d2", null ],
    [ "bReadLock", "d6/d78/structphNfcLib__I18000p3m3.html#a6997fadcf1ab0f162fe14fab7ce45f92", null ],
    [ "pWordPtr", "d6/d78/structphNfcLib__I18000p3m3.html#a9fa81c9ba5802e12539fd5a0338b67c1", null ],
    [ "bWordPtrLength", "d6/d78/structphNfcLib__I18000p3m3.html#ae6fe3ed76ef5959c9977f1e6a892c5b8", null ],
    [ "bWordCount", "d6/d78/structphNfcLib__I18000p3m3.html#aaa14c07c49a92255b38f8c5f6e38913c", null ],
    [ "pPassword", "d6/d78/structphNfcLib__I18000p3m3.html#a4743991a6d3280f218a95b5532b6e2ba", null ],
    [ "bRecom", "d6/d78/structphNfcLib__I18000p3m3.html#a0677e817d0943cf122091390fb168868", null ],
    [ "pMask", "d6/d78/structphNfcLib__I18000p3m3.html#a9e6f27ff53255d539c3751f640f1d47d", null ],
    [ "pAction", "d6/d78/structphNfcLib__I18000p3m3.html#adfdbc618754f19fb90526624d215da98", null ],
    [ "pBlockPtr", "d6/d78/structphNfcLib__I18000p3m3.html#ad7e8a8b102a55a506a423977afdfd7cf", null ],
    [ "bBlockPtrLength", "d6/d78/structphNfcLib__I18000p3m3.html#af9181e058363279b29667e4025f26385", null ],
    [ "bBlockRange", "d6/d78/structphNfcLib__I18000p3m3.html#acdf5ccaddf8c482253e6e30c6fcacfbb", null ],
    [ "pHandle", "d6/d78/structphNfcLib__I18000p3m3.html#a5d709b8800ca5403956d9ab67a26221c", null ],
    [ "pUii", "d6/d78/structphNfcLib__I18000p3m3.html#a9b8da07b30c45ee03a6ecadfd8549f27", null ],
    [ "wUiiMaskLength", "d6/d78/structphNfcLib__I18000p3m3.html#a3e0a504710311f8efd333367a1753d9b", null ],
    [ "pBuffer", "d6/d78/structphNfcLib__I18000p3m3.html#ae6e33991372bfec7c218034538e71693", null ]
];