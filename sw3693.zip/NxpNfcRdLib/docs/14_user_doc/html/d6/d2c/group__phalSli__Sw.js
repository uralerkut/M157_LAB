var group__phalSli__Sw =
[
    [ "phalSli_Sw_DataParams_t", "d3/d37/structphalSli__Sw__DataParams__t.html", [
      [ "wId", "d3/d37/structphalSli__Sw__DataParams__t.html#affc5aab2c2329ad83ae17a8f11167ffb", null ],
      [ "pPalSli15693DataParams", "d3/d37/structphalSli__Sw__DataParams__t.html#af6468625f77b971bf7c6025981bde181", null ]
    ] ],
    [ "PHAL_SLI_SW_ID", "d6/d2c/group__phalSli__Sw.html#ga04965982f9b7c9dc7a089a6bca75d295", null ],
    [ "phalSli_Sw_Init", "d6/d2c/group__phalSli__Sw.html#gab69f3ef9b824693291b724474a743d1c", null ]
];