var structphacDiscLoop__Sw__TypeB__Info_1_1phacDiscLoop__TypeB__I3P4B =
[
    [ "bMbli", "d6/dd0/structphacDiscLoop__Sw__TypeB__Info_1_1phacDiscLoop__TypeB__I3P4B.html#a6af3729595f3e4a1fbc22ae3c6c29e18", null ],
    [ "bParam1", "d6/dd0/structphacDiscLoop__Sw__TypeB__Info_1_1phacDiscLoop__TypeB__I3P4B.html#a1c69965a732f16c71059356fc4a3375e", null ]
];