var structphalTop__T5T =
[
    [ "pAlI15693DataParams", "d6/dc4/structphalTop__T5T.html#a344ea6de66c7b4178b6a46804176f0ac", null ],
    [ "bRwa", "d6/dc4/structphalTop__T5T.html#ae1b44619ea23eb72cd17f5eb3e7ef30c", null ],
    [ "bTerminatorTlvPresence", "d6/dc4/structphalTop__T5T.html#a6c004dfae809b6252d4caff6f475b73d", null ],
    [ "bMbRead", "d6/dc4/structphalTop__T5T.html#a571f948d2907080cc65b166404bfb08e", null ],
    [ "bLockBlock", "d6/dc4/structphalTop__T5T.html#a8ba57cc98ce9897bd2b8ea15aabf8b20", null ],
    [ "bSplFrm", "d6/dc4/structphalTop__T5T.html#a6363eef73ceaa5a3413dc1b66fc07ebb", null ],
    [ "bExtendedCommandSupport", "d6/dc4/structphalTop__T5T.html#ae28a8ab0b75b4735f3266247abf62b03", null ],
    [ "bOptionFlag", "d6/dc4/structphalTop__T5T.html#ad77aadd55eb972d6561df9998f2342a0", null ],
    [ "wMlen", "d6/dc4/structphalTop__T5T.html#a7c7bec8130b539fb7ccc21f3d9050ec6", null ],
    [ "wNdefHeaderAddr", "d6/dc4/structphalTop__T5T.html#a94a76d90a4cbed12d3279379aa4dd9f1", null ],
    [ "wNdefMsgAddr", "d6/dc4/structphalTop__T5T.html#a8bb6383947d4a9d2e6eefdbc91d84b5f", null ],
    [ "bBlockSize", "d6/dc4/structphalTop__T5T.html#aa52a7bf6d6380a8f9f39c175e1da64d3", null ],
    [ "bMaxBlockNum", "d6/dc4/structphalTop__T5T.html#a75f17e639f2328eae97628bfb9f357cf", null ]
];