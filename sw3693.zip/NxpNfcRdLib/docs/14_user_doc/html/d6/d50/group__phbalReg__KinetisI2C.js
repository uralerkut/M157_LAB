var group__phbalReg__KinetisI2C =
[
    [ "phbalReg_KinetisI2C_DataParams_t", "d9/dd7/structphbalReg__KinetisI2C__DataParams__t.html", null ],
    [ "PHBAL_REG_KINETIS_I2C_ID", "d6/d50/group__phbalReg__KinetisI2C.html#ga69c24859d40eef792423d2575ccb1c27", null ],
    [ "phbalReg_KinetisI2C_Init", "d6/d50/group__phbalReg__KinetisI2C.html#ga84ca39c3812f834d409f2d8371fa7a11", null ]
];