var structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS =
[
    [ "bDid", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html#a7c22eed1d2c2da4f8a7f12a1633b0070", null ],
    [ "bLri", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html#a48aff0ef090be173f392d10dda362479", null ],
    [ "bNadEnable", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html#a70d7a83824353db0dc7e48c078e3897f", null ],
    [ "bNad", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html#a2933bd0eaf697487e6e79e68ed79556b", null ],
    [ "pGi", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html#a79a6eb9cea50bcf6a5018c7039cada91", null ],
    [ "bGiLength", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html#a3429e0f2ccb75984a6946290ce060dd4", null ],
    [ "pAtrRes", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html#ae61d8389cb33ffdb948c83d692643616", null ],
    [ "bAtrResLength", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html#aa1bbcf482010ec8036d292d62c81dfa6", null ]
];