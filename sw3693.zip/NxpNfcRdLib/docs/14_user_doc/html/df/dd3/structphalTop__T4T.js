var structphalTop__T4T =
[
    [ "pAlT4TDataParams", "df/dd3/structphalTop__T4T.html#a39a53ace181556495fbe2cae25b5bdd7", null ],
    [ "aNdefFileID", "df/dd3/structphalTop__T4T.html#afa355a60b18e937d1f13e00bf7c0d2c1", null ],
    [ "bRa", "df/dd3/structphalTop__T4T.html#a7f6cd9f760c1dd080b3b9b0165c97514", null ],
    [ "bWa", "df/dd3/structphalTop__T4T.html#a2dc7c54f1036f04dc5a6b7836feb303e", null ],
    [ "bCurrentSelectedFile", "df/dd3/structphalTop__T4T.html#a02bb17008ffb5879e9a8c93b731fa49d", null ],
    [ "wMLe", "df/dd3/structphalTop__T4T.html#ab17d80de9aeb0dfffad5843ab2f64ec1", null ],
    [ "wMLc", "df/dd3/structphalTop__T4T.html#a28e5c238836e8800c8b2606287dc88d0", null ],
    [ "wCCLEN", "df/dd3/structphalTop__T4T.html#a257693511226a01a8f24890e7fd4b289", null ],
    [ "wMaxFileSize", "df/dd3/structphalTop__T4T.html#a76dc756ef9361a68c726ce7a6e74d237", null ]
];