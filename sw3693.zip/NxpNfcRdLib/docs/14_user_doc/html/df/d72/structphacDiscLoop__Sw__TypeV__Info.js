var structphacDiscLoop__Sw__TypeV__Info =
[
    [ "bTotalTagsFound", "df/d72/structphacDiscLoop__Sw__TypeV__Info.html#ac14cac97a205684b4307a1d4cdec88e1", null ],
    [ "bFlag", "df/d72/structphacDiscLoop__Sw__TypeV__Info.html#ae85aa5e59cfcebdb9be6c4cdfa51b155", null ]
];