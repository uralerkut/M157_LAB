var structphpalI14443p4a__Sw__DataParams__t =
[
    [ "wId", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a342828b7022190cd12c9cff9b8e60c96", null ],
    [ "pHalDataParams", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a00c2d09588fab370445a64f18e01a7ac", null ],
    [ "bCidSupported", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#aa0a0963450f5617c5ffb0bd6427af231", null ],
    [ "bNadSupported", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a449d6fa98897aff203d65b1c43f2c396", null ],
    [ "bCid", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#ad111f1cf7ec8a98a58b4f74b8d54838f", null ],
    [ "bBitRateCaps", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a4369126b4463eeda921977a52a5ee119", null ],
    [ "bFwi", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a7a6e056f1c4cace6415af4f1e079ae47", null ],
    [ "bFsci", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a736d3f9a088f6c9fd718120c7162adc1", null ],
    [ "bFsdi", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a50d7481fdf649d71508d1676a834b33d", null ],
    [ "bDri", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#acc03321a579e77551312984a68c518d6", null ],
    [ "bDsi", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#aa189915a0574e37390574d0aec32dd97", null ],
    [ "bOpeMode", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a62f0eed968a7930e43021ec460309c0b", null ],
    [ "bRetryCount", "de/d67/structphpalI14443p4a__Sw__DataParams__t.html#a1ab1e6e0a274bb3b854f1ea5d225729d", null ]
];