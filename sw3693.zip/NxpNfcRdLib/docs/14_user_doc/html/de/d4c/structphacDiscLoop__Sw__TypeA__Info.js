var structphacDiscLoop__Sw__TypeA__Info =
[
    [ "phacDiscLoop_Type_P2P_TAGS", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS.html", "df/db6/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__Type__P2P__TAGS" ],
    [ "phacDiscLoop_TypeA_I3P3", "d3/d21/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__TypeA__I3P3.html", "d3/d21/structphacDiscLoop__Sw__TypeA__Info_1_1phacDiscLoop__TypeA__I3P3" ],
    [ "phascDiscLoop_TypeA_I3P4", "dc/d0d/structphacDiscLoop__Sw__TypeA__Info_1_1phascDiscLoop__TypeA__I3P4.html", "dc/d0d/structphacDiscLoop__Sw__TypeA__Info_1_1phascDiscLoop__TypeA__I3P4" ],
    [ "bTotalTagsFound", "de/d4c/structphacDiscLoop__Sw__TypeA__Info.html#a376a4b639a7c2151cd5a270287f4a8bc", null ],
    [ "bT1TFlag", "de/d4c/structphacDiscLoop__Sw__TypeA__Info.html#a941a3e320db3acf2ffe6a935ec5c0e9f", null ]
];