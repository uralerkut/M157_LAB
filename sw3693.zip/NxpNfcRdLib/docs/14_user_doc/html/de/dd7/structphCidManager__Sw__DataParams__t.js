var structphCidManager__Sw__DataParams__t =
[
    [ "wId", "de/dd7/structphCidManager__Sw__DataParams__t.html#a39eb3a4b5a3f30993804bf2bc5441b22", null ],
    [ "bCidList", "de/dd7/structphCidManager__Sw__DataParams__t.html#a08c568bfd86cf67b25bf6af315399ff5", null ]
];