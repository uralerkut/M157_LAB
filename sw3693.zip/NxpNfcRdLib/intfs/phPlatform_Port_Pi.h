/*
 * phPlatform_LpcPort.h
 *
 *  Created on: Apr 11, 2016
 *      Author: nxp69678
 */

#ifndef PHPLATFORM_PORT_PI_H
#define PHPLATFORM_PORT_PI_H

#if defined(NXPBUILD__PH_RASPBERRY_PI)

#define phPlatform_EnterCriticalSection()

#define phPlatform_ExitCriticalSection()

#endif /* NXPBUILD__PH_RASPBERRY_PI */

#endif /* PHPLATFORM_PORT_PI_H */
